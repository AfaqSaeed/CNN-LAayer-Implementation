class BaseLayer:
    ##### Add a parameter trainable to check if layer is trainable or not ##########
    def __init__(self) -> None:
        self.trainable = False
 